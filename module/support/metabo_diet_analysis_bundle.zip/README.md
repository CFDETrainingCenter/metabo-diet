# Metabo-Diet runnable analysis bundle

This archive preserves the paths expected by the executed notebook. Extract the
whole archive, keeping the `module/` directory intact.

## Python cached path

From the directory containing `module/`, create an environment, install the
execution dependencies, and run the notebook top-to-bottom:

```bash
python -m venv .venv
.venv/bin/pip install -r module/notebooks/requirements-dev.txt
.venv/bin/python module/scripts/execute_notebook.py
```

The bundled `module/data/raw/` files support the offline fallback; outputs are
written to `module/data/derived/` and `module/figures/`. If a Jupyter UI is
already installed, you may instead open the notebook interactively from its
existing path, but keep the full `module/` tree intact.

The notebook imports `module/scripts/metabo_diet_pipeline.py`; do not separate
the notebook from the rest of the module tree. See `module/data/provenance.json`
and `module/ATTRIBUTION.md` for retrieval evidence, checksums, and licensing.

Original Metabo-Diet training materials are licensed under CC BY 4.0; see the
root `LICENSE` file. Third-party data retain the source licenses described in
`module/ATTRIBUTION.md` and `module/data/provenance.json`.

## R appendix

The source and rendered appendix are in `module/notebooks/`. The HTML is a
viewable cached-path record. Live retrieval requires the R packages named by
the R Markdown source and network access to the repository service.

Scientific boundary: the two studies are explored separately. Do not pool
uncalibrated plasma and serum peak-area matrices.
