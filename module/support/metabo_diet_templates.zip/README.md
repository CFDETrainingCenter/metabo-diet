# Metabo-Diet learner templates

Editable Markdown and CSV versions of the three learner artifacts are in worksheets/.
For the runnable Python notebook, cached public inputs, pipeline, figures, and R appendix,
download metabo_diet_analysis_bundle.zip alongside this worksheet bundle.

Scientific boundary: do not concatenate uncalibrated peak-area matrices across the two studies.
Preserve the source accession, analysis ID, specimen, timepoint, and mapping evidence.
Original training materials are licensed under CC BY 4.0; see LICENSE and DATA_ATTRIBUTION.md.

## Included files

- DATA_ATTRIBUTION.md
- LICENSE
- module/data/provenance.json
- worksheets/access_tier_transfer_checklist.csv
- worksheets/access_tier_transfer_checklist.md
- worksheets/cohort_comparison_worksheet.csv
- worksheets/cohort_comparison_worksheet.md
- worksheets/metabolite_metadata_crosswalk.csv
- worksheets/metabolite_metadata_crosswalk.md
- worksheets/metadata_crosswalk.csv
- worksheets/refmet_overlap_audit.csv
- worksheets/unit_compatibility_audit.csv
