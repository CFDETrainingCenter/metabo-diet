# Metabo-Diet learner and analysis bundle

## Start here

1. Extract this whole archive. Keep the `module/` directory intact.
2. Open `module/support/metabo_diet_learner_guide.pdf`.
3. Extract `module/support/metabo_diet_templates.zip` and keep the three worksheets nearby.
4. Follow the first-time setup in the guide or `module/content/getting_started.md`.
5. Complete the pretest, then move through guide Lessons 1 to 5 and notebook sections `NB-L1` to `NB-L5` together.

The Python notebook is the main activity. The R companion is optional. The
validated public cache is the default, so live API access is not required after
packages are installed.

## Interactive Python path

From the directory containing `module/`, run the commands for your system.

macOS or Linux:

```bash
python3.12 --version
python3.12 -m venv .venv
./.venv/bin/python -m pip install -r module/notebooks/requirements-dev.txt
./.venv/bin/python -m jupyter lab module/notebooks/metabo_diet_harmonization.ipynb
```

Windows PowerShell:

```powershell
py -3.12 --version
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r module\notebooks\requirements-dev.txt
.\.venv\Scripts\python.exe -m jupyter lab module\notebooks\metabo_diet_harmonization.ipynb
```

Python 3.11 is also supported. The setup guide explains how to run cells and
what to do when a check fails. Outputs are written to `module/data/derived/`
and `module/figures/`.

## Optional installation smoke test

This command runs every code cell without pausing for learner edits. It checks
the installation but does not complete the course and does not overwrite the
source notebook:

```bash
./.venv/bin/python module/scripts/execute_notebook.py --output metabo_diet_smoke_test.ipynb
```

The notebook imports `module/scripts/metabo_diet_pipeline.py`; do not separate
the notebook from the rest of the module tree. See `module/data/provenance.json`
and `module/ATTRIBUTION.md` for retrieval records, checksums, and licensing.

Original Metabo-Diet training materials are licensed under CC BY 4.0; see the
root `LICENSE` file. Third-party data retain the source licenses described in
`module/ATTRIBUTION.md` and `module/data/provenance.json`.

## R appendix

The source and rendered appendix are in `module/notebooks/`. The HTML is a
viewable cached-path record. Live retrieval requires the R packages named by
the R Markdown source and network access to the repository service.

Scientific boundary: the two studies are explored separately. Do not pool
uncalibrated plasma and serum peak-area matrices.
